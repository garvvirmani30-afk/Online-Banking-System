#include <iostream>
#include <fstream>
#include <string>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

void handleClient(SOCKET clientSocket) {
    char buffer[3000] = {0};
    recv(clientSocket, buffer, sizeof(buffer), 0);

    string request(buffer);
    cout << "Request:\n" << request << endl;

    string response;

    // ROUTE: /balance
    if (request.find("GET /balance") != string::npos) {
        ifstream file("users.txt");
        string user, pass;
        int balance;

        string body;

        if (file >> user >> pass >> balance) {
            body = "Balance: " + to_string(balance);
        } else {
            body = "Error: Unable to read users.txt";
        }

        response = "HTTP/1.1 200 OK\r\n";
        response += "Access-Control-Allow-Origin: *\r\n";
        response += "Content-Type: text/plain\r\n\r\n";
        response += body;
    }
    else {
        response = "HTTP/1.1 200 OK\r\n";
        response += "Access-Control-Allow-Origin: *\r\n";
        response += "Content-Type: text/plain\r\n\r\n";
        response += "C++ Bank Server Running";
    }

    send(clientSocket, response.c_str(), response.length(), 0);
    closesocket(clientSocket);
}

int main() {
    WSADATA wsa;
    SOCKET serverSocket, clientSocket;
    struct sockaddr_in server, client;
    int c;

    // Start Winsock
    WSAStartup(MAKEWORD(2,2), &wsa);

    // Create socket
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);

    // Configure server
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(8080);

    // Bind
    bind(serverSocket, (struct sockaddr*)&server, sizeof(server));

    // Listen
    listen(serverSocket, 3);

    cout << "Server started at http://localhost:8080\n";

    c = sizeof(struct sockaddr_in);

    while (true) {
        clientSocket = accept(serverSocket, (struct sockaddr*)&client, &c);
        handleClient(clientSocket);
    }

    return 0;
}