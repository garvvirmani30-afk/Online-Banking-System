#include "crow_all.h"
#include <fstream>
#include <vector>
using namespace std;

struct User {
    string username;
    string password;
    float balance;
};

// ---------- Load Users ----------
vector<User> loadUsers() {
    vector<User> users;
    ifstream file("users.txt");
    User u;

    while (file >> u.username >> u.password >> u.balance) {
        users.push_back(u);
    }
    return users;
}

// ---------- Save Users ----------
void saveUsers(const vector<User>& users) {
    ofstream file("users.txt");
    for (auto &u : users) {
        file << u.username << " " << u.password << " " << u.balance << endl;
    }
}

// ---------- CORS Response Helper ----------
crow::response makeRes(string msg) {
    crow::response res(msg);
    res.add_header("Access-Control-Allow-Origin", "*");
    res.add_header("Access-Control-Allow-Headers", "Content-Type");
    res.add_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    return res;
}

int main() {

    crow::SimpleApp app;

    // ---------- Handle OPTIONS (CORS Preflight) ----------
    CROW_ROUTE(app, "/<path>")
    .methods("OPTIONS"_method)
    ([](const crow::request&, string){
        return makeRes("");
    });

    // ---------- Root ----------
    CROW_ROUTE(app, "/")([](){
        return makeRes("Online Banking Server Running");
    });

    // ---------- Signup ----------
    CROW_ROUTE(app, "/signup").methods("POST"_method)
    ([](const crow::request& req) {
        auto data = crow::json::load(req.body);
        if (!data) return makeRes("Invalid Data");

        string user = data["username"].s();
        string pass = data["password"].s();

        auto users = loadUsers();
        for (auto &u : users) {
            if (u.username == user)
                return makeRes("User already exists");
        }

        ofstream file("users.txt", ios::app);
        file << user << " " << pass << " 0\n";

        return makeRes("Signup Successful");
    });

    // ---------- Login ----------
    CROW_ROUTE(app, "/login").methods("POST"_method)
    ([](const crow::request& req) {
        auto data = crow::json::load(req.body);
        if (!data) return makeRes("Invalid Data");

        string user = data["username"].s();
        string pass = data["password"].s();

        auto users = loadUsers();
        for (auto &u : users) {
            if (u.username == user && u.password == pass)
                return makeRes("success");
        }
        return makeRes("Invalid Credentials");
    });

    // ---------- Balance ----------
    CROW_ROUTE(app, "/balance").methods("POST"_method)
    ([](const crow::request& req) {
        auto data = crow::json::load(req.body);
        if (!data) return makeRes("Invalid Data");

        string user = data["username"].s();

        auto users = loadUsers();
        for (auto &u : users) {
            if (u.username == user)
                return makeRes("Balance: " + to_string(u.balance));
        }
        return makeRes("User not found");
    });

    // ---------- Deposit ----------
    CROW_ROUTE(app, "/deposit").methods("POST"_method)
    ([](const crow::request& req) {
        auto data = crow::json::load(req.body);
        if (!data) return makeRes("Invalid Data");

        string user = data["username"].s();
        float amt = data["amount"].d();

        if (amt <= 0) return makeRes("Invalid Amount");

        auto users = loadUsers();
        for (auto &u : users) {
            if (u.username == user) {
                u.balance += amt;
                saveUsers(users);
                return makeRes("Deposited Successfully");
            }
        }
        return makeRes("User not found");
    });

    // ---------- Withdraw ----------
    CROW_ROUTE(app, "/withdraw").methods("POST"_method)
    ([](const crow::request& req) {
        auto data = crow::json::load(req.body);
        if (!data) return makeRes("Invalid Data");

        string user = data["username"].s();
        float amt = data["amount"].d();

        auto users = loadUsers();
        for (auto &u : users) {
            if (u.username == user) {

                if (amt <= 0)
                    return makeRes("Invalid Amount");

                if (u.balance < amt)
                    return makeRes("Insufficient Balance");

                u.balance -= amt;
                saveUsers(users);
                return makeRes("Withdrawn Successfully");
            }
        }
        return makeRes("User not found");
    });

    // ---------- Reset Password ----------
    CROW_ROUTE(app, "/reset").methods("POST"_method)
    ([](const crow::request& req) {
        auto data = crow::json::load(req.body);
        if (!data) return makeRes("Invalid Data");

        string user = data["username"].s();
        string newPass = data["newPassword"].s();

        auto users = loadUsers();
        for (auto &u : users) {
            if (u.username == user) {
                u.password = newPass;
                saveUsers(users);
                return makeRes("Password Reset Successful");
            }
        }
        return makeRes("User not found");
    });

    app.port(5000).multithreaded().run();
}