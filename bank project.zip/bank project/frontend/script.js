// ---------------- LOGIN ----------------
function login() {
    let user = document.getElementById("username").value.trim();
    let pass = document.getElementById("password").value.trim();

    if(user === "garv" && pass === "1234") {
        localStorage.setItem("username", user);   // ✅ store user
        window.location.href = "dashboard.html";
    } else {
        alert("Invalid login");
    }
}

// ---------------- GLOBAL DATA ----------------
let balance = 0;
let fdBalance = 0;
let fdTime = 0;

// ---------------- ON PAGE LOAD ----------------
window.onload = function() {
    // Show username
    let user = localStorage.getItem("username");
    if(user) {
        document.getElementById("user").innerText = "Welcome, " + user;
    }

    // Load balance from backend
    getBalance();

    // Initialize UI
    updateUI();
};

// ---------------- GET BALANCE ----------------
function getBalance() {
    fetch("http://localhost:8080/balance")
    .then(res => res.text())
    .then(data => {
        document.getElementById("balance").innerText = data;

        // Extract number safely
        let parts = data.split(":");
        if(parts.length > 1) {
            balance = parseInt(parts[1]) || 0;
        }

        updateUI();
    })
    .catch(() => {
        alert("Server not running");
    });
}

// ---------------- DEPOSIT ----------------
function deposit() {
    let amt = parseInt(document.getElementById("depositAmt").value);

    if (!amt || amt <= 0) {
        alert("Enter valid amount");
        return;
    }

    balance += amt;
    updateBalance("Deposited ₹" + amt);
}

// ---------------- WITHDRAW ----------------
function withdraw() {
    let amt = parseInt(document.getElementById("withdrawAmt").value);

    if (!amt || amt <= 0) {
        alert("Enter valid amount");
        return;
    }

    if (amt > balance) {
        alert("Insufficient balance");
        return;
    }

    balance -= amt;
    updateBalance("Withdrawn ₹" + amt);
}

// ---------------- CREATE FD ----------------
function createFD() {
    let amt = parseInt(document.getElementById("fdAmount").value);
    let time = parseInt(document.getElementById("fdTime").value);

    if (!amt || amt <= 0) {
        alert("Enter valid FD amount");
        return;
    }

    if (!time || time <= 0) {
        alert("Enter valid duration");
        return;
    }

    if (amt > balance) {
        alert("Not enough balance");
        return;
    }

    balance -= amt;
    fdBalance += amt;
    fdTime = time;

    updateBalance("FD Created: ₹" + amt + " for " + time + " months");
}

// ---------------- UPDATE UI ----------------
function updateUI() {
    document.getElementById("balance").innerText = "₹" + balance;
    document.getElementById("fdInfo").innerText = "₹" + fdBalance;
}

// ---------------- UPDATE BALANCE + HISTORY ----------------
function updateBalance(message) {
    updateUI();

    let li = document.createElement("li");
    li.innerText = message;
    document.getElementById("history").appendChild(li);
}

// ---------------- LOGOUT ----------------
function logout() {
    localStorage.removeItem("username");
    window.location.href = "index.html";
}
